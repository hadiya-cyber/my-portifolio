# Hadiya Ahmed — Personal Portfolio

A responsive personal portfolio built with HTML, CSS, and Bootstrap 5.

## Files
- `index.html` — page structure and content
- `style.css` — custom styling

## Run it
1. Download or extract this folder.
2. Open `index.html` in a browser.
3. An internet connection is needed to load Bootstrap from its CDN.

## Customize before publishing
- Check the education wording and update it to your exact university/program details if you want to show them.
- Add a professional email address in the Contact section when you are comfortable sharing it publicly.
- Replace the learning-project descriptions with your real work as you complete projects.
- Add repository links and screenshots only after those projects exist.
- Keep project statuses honest: planned, in progress, or completed.

GitHub profile: https://github.com/hadiya-cyber
