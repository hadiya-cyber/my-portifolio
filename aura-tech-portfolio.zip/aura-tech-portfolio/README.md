# AURA — Responsive Technology Landing Page

A student portfolio concept project inspired by minimalist technology product websites. AURA is an original fictional brand and is not affiliated with Apple.

## Features
- Responsive desktop, tablet and mobile layouts
- Mobile navigation menu built with JavaScript
- Product showcase cards
- CSS-built device illustrations (no image downloads required)
- Semantic HTML and accessible navigation labels
- CSS Grid, Flexbox, transitions and media queries

## Technologies
HTML5, CSS3, JavaScript (vanilla)

## Run locally
Open `index.html` in a browser. No build tools or installation are required.

## Customize
- Change the brand name and copy in `index.html`.
- Change colors in the `:root` section of `style.css`.
- Update the contact email in the contact section.
- Add your GitHub repository URL to your scholarship application after publishing.

## Author
Hadiya — student portfolio project, 2026.
